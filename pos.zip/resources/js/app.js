console.log('laravel-mix is load');
var QRCode = require('qrcode');
module.exports = { QRCode };
