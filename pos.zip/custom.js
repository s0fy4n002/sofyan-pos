const QRCode = require('qrcode');
global.window.QRCode = QRCode;
